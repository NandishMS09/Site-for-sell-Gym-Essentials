
$(document).ready(function(){
    $("#home").css({
        "border":"5px solid #171717",
        "padding": "0px 5px",
        "background-color":"#DDDDDD",
        "color":"tomato",
    });
    
});

